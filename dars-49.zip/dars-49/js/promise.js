async function x () {
	let vada = await fetch('https://jsonplaceholder.typicode.com/users', {
		method: "GET"
	})

	let data = await vada.json()
	for(let d of data) {
		console.log(d.username)
	}
}

x()






// vada.then( (data) => data.json() )
// 	.then( (data) => console.log(data) )
// 	.catch( error => console.log(error))

